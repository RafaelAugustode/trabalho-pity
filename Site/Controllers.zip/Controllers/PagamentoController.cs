﻿using Microsoft.AspNetCore.Mvc;

namespace DataVault.Controllers
{
    public class PagamentoController : Controller
    {
    }
}
