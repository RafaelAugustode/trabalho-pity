﻿using Microsoft.AspNetCore.Mvc;

namespace DataVault.Controllers
{
    public class FeedbackController : Controller
    {


    }
}
