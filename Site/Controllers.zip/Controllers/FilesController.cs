﻿using Microsoft.AspNetCore.Mvc;

namespace DataVault.Controllers
{
    public class FilesController : Controller
    {
        [HttpPost]
        public IActionResult Upload(IFormFile arquivo)
        {
            if (arquivo != null && arquivo.Length > 0)
            {
                var caminho = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot/uploads", arquivo.FileName);

                using (var stream = new FileStream(caminho, FileMode.Create))
                {
                    arquivo.CopyTo(stream);
                }

                return Ok("Upload concluído com sucesso!");
            }

            return BadRequest("Nenhum arquivo enviado.");
        }
    }
}
