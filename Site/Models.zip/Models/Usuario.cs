using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace DataVault.Models
{
	[Table("usuario")]
	public class Usuario
	{
		[Key]
		[Column("id")]
		public int Id { get; set; }

		[Required]
		[Column("nome_cliente")]
		public string NomeCliente { get; set; } = string.Empty;

		[Required]
		[Column("senha")]
		public string Senha { get; set; } = string.Empty;

		[Required]
		[Column("email")]
		public string Email { get; set; } = string.Empty;

		public ICollection<Feedback> Feedbacks { get; set; }
		public ICollection<Perfil> Perfis { get; set; }
		public ICollection<Files> Arquivos { get; set; }
	}

}
