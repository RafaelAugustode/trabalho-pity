﻿function icon() {
    document.querySelector(".Pagina-Login").classList.toggle("active");
}
