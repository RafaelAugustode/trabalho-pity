using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace DataVault.Views.Shared
{
    public class _LayoutCleanModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
