﻿using DataVault.Data;
using DataVault.Models;
using Microsoft.EntityFrameworkCore;

namespace DataVault.Repositories
{
	public class FeedbackRepository : Repository<Feedback>, IFeedbackRepository
	{
		public FeedbackRepository(ApplicationDbContext context) : base(context) { }

		public async Task<IEnumerable<Feedback>> GetByMonthAsync(int month, int year)
		{
			return await _context.Feedbacks
	   .Where(f => f.DataCriacao.Month == month && f.DataCriacao.Year == year)
	   .ToListAsync();
		}
	}
}
