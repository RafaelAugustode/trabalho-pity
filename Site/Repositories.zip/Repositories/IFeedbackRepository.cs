﻿using DataVault.Models;

namespace DataVault.Repositories
{
	public interface IFeedbackRepository : IRepository<Feedback>
	{
		Task<IEnumerable<Feedback>> GetByMonthAsync(int month, int year);
	}
}
